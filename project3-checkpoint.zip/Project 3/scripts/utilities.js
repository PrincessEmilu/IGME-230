"use strict"
//Gets a random number
function getRandom(min, max) {
    return Math.random() * (max - min) + min;
}